from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    # django_template_text = "hello from django"
    # return HttpResponse("<h1>Hello world! You are at the buryak app.</h1> %s" % django_template_text)
    return render(request, "notes.html", context={"first_name": "Andrew"})
