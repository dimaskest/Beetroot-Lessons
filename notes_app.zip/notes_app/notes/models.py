from django.db import models

# Create your models here.
class Category(models.Model):
    title = models.CharField(max_length=200)

    def __str__(self) -> str:
        return f"{self.title}"


class Note(models.Model):
    text = models.TextField()
    title = models.ForeignKey(Category, on_delete=models.CASCADE)
    reminder = models.CharField(max_length=200)

    def publish(self):
        self.save()

    def __str__(self) -> str:
        return f"Category: {self.title}. Reminder: {self.reminder}, {self.text}"