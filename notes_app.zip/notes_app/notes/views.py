from django.shortcuts import render
from .models import Category, Note


def notes_list(request):
    return render(request, 'notes/notes_list.html', {'notes': Note.objects.all()})